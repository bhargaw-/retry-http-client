package com.example;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

import java.util.Objects;
import java.util.concurrent.*;

@Component
@Slf4j
public class RetryHttpClient implements AutoCloseable {
    private final ExecutorService executorService;

    RetryHttpClient() {
        this.executorService = Executors.newVirtualThreadPerTaskExecutor();
    }

    public <T, R> ResponseEntity<R> getResponseEntity(APIRequest<T, R> apiRequest) {
        int noOfRetries = 0;
        RestClient.RequestBodySpec requestBodySpec = getRequestBodySpec(apiRequest);
        log.info("Target endpoint url; {}, Method: {}", apiRequest.getUri(), apiRequest.getHttpMethod());
        while (true) {
            try {
                ResponseEntity<R> responseEntity = requestBodySpec.retrieve()
                        .toEntity(apiRequest.getResponseType());
                log.info("Api call is successful. Target endpoint url; {}, Method: {}, Http Status : {}",
                        apiRequest.getUri(), apiRequest.getHttpMethod(), responseEntity.getStatusCode());
                return responseEntity;
            } catch (RestClientResponseException e) {
                log.info("Api call is failed. Target endpoint url; {}, Method: {}, Http Status : {}, reason: {} ",
                        apiRequest.getUri(), apiRequest.getHttpMethod(), e.getStatusCode(), e.getResponseBodyAsString());
                if (noOfRetries == apiRequest.getMaxRetryCount()) {
                    throw e;
                }
            } catch (RestClientException e) {
                log.info("Untreatable exception. Target endpoint url; {}, Method: {}, reason: {} ",
                        apiRequest.getUri(), apiRequest.getHttpMethod(), e.getLocalizedMessage());
                throw e;
            }
            try {
                TimeUnit.SECONDS.sleep(apiRequest.getFixedDelay());
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
            noOfRetries += 1;
            log.info("Target endpoint url; {}, Method: {}, No.of retries : {}, Max retries: {} ",
                    apiRequest.getUri(), apiRequest.getHttpMethod(), noOfRetries, apiRequest.getMaxRetryCount());
        }
    }

    private static <T, R> RestClient.RequestBodySpec getRequestBodySpec(APIRequest<T, R> apiRequest) {
        RestClient.RequestBodySpec requestBodySpec = apiRequest.getRestClient()
                .method(apiRequest.getHttpMethod())
                .uri(apiRequest.getUri())
                .headers(httpHeaders -> httpHeaders.putAll(apiRequest.getHttpHeaders()));
        if (Objects.nonNull(apiRequest.getRequestBody())) {
            requestBodySpec = requestBodySpec.body(apiRequest.getRequestBody());
        }
        return requestBodySpec;
    }

    public <T, R> ResponseEntity<R> getResponse(APIRequest<T, R> apiRequest) {
        try {
            int timeOut = (apiRequest.getFixedDelay() * apiRequest.getMaxRetryCount()) + 1;
            log.info("total time out id {} seconds.", timeOut);
            return this.executorService.submit(() -> this.getResponseEntity(apiRequest))
                    .get(timeOut, TimeUnit.SECONDS);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (TimeoutException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void close() {
        if (Objects.nonNull(this.executorService)) {
            this.executorService.close();
        }
    }
}
