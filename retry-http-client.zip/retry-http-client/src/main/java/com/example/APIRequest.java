package com.example;

import lombok.Getter;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Map;
import java.util.Objects;

@Getter
public class APIRequest<T, R> {
    private final RestClient restClient;
    private final MultiValueMap<String, String> requestParams;
    private final Map<String, Object> uriVariables;
    private final String baseUrl;
    private final String path;
    private final HttpHeaders httpHeaders;
    private final HttpMethod httpMethod;
    private final T requestBody;
    private final ParameterizedTypeReference<R> responseType;
    private final URI uri;
    private final int maxRetryCount;
    private final int fixedDelay;

    public static <T, R> Builder<T, R> builder() {
        return new Builder<>();
    }

    private APIRequest(Builder<T, R> builder) {
        this.restClient = Objects.requireNonNull(builder.restClient, "restClient must not be null");;
        this.baseUrl = Objects.requireNonNull(builder.baseUrl, "baseUrl must not be null");
        this.path = Objects.requireNonNullElse(builder.path, "");
        this.requestParams = Objects.requireNonNullElse(builder.requestParams, new LinkedMultiValueMap<>());
        this.uriVariables =  Objects.requireNonNullElse(builder.uriVariables, Map.of());
        this.httpHeaders = Objects.requireNonNullElse(builder.httpHeaders, new HttpHeaders());
        this.httpMethod = Objects.requireNonNullElse(builder.httpMethod, HttpMethod.GET);
        this.requestBody = builder.requestBody;
        this.responseType = Objects.requireNonNull(builder.responseType, "responseType must not be null");
        this.fixedDelay = builder.fixedDelay;
        this.maxRetryCount = builder.maxRetryCount <= 0 ? 1 : builder.maxRetryCount;
        this.uri = Objects.requireNonNullElse(builder.uri, this.uri());
    }

    private URI uri() {
        return UriComponentsBuilder.fromHttpUrl(baseUrl)
                .path(path)
                .uriVariables(uriVariables)
                .replaceQueryParams(requestParams)
                .build()
                .toUri();
    }

    public static class Builder<T, R> {
        private RestClient restClient;
        private MultiValueMap<String, String> requestParams;
        private Map<String, Object> uriVariables;
        private String baseUrl;
        private String path;
        private HttpHeaders httpHeaders;
        private HttpMethod httpMethod;
        private T requestBody;
        private ParameterizedTypeReference<R> responseType;
        private URI uri;
        private int maxRetryCount;
        private int fixedDelay;

        Builder<T, R> restClient(RestClient restClient) {
            this.restClient = restClient;
            return this;
        }

        Builder<T, R> baseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
            ;
            return this;
        }

        Builder<T, R> path(String path) {
            this.path = path;
            return this;
        }

        Builder<T, R> requestParams(MultiValueMap<String, String> requestParams) {
            this.requestParams = requestParams;
            return this;
        }

        Builder<T, R> uriVariables(Map<String, Object> uriVariables) {
            this.uriVariables =uriVariables;
            return this;
        }

        Builder<T, R> httpHeaders(HttpHeaders httpHeaders) {
            this.httpHeaders = httpHeaders;
            return this;
        }

        Builder<T, R> httpMethod(HttpMethod httpMethod) {
            this.httpMethod = httpMethod;
            return this;
        }

        Builder<T, R> maxRetryCount(int maxRetryCount) {
            this.maxRetryCount = maxRetryCount;
            return this;
        }

        Builder<T, R> fixedDelay(int fixedDelay) {
            this.fixedDelay = fixedDelay;
            return this;
        }

        Builder<T, R> requestBody(T requestBody) {
            this.requestBody = requestBody;
            return this;
        }

        Builder<T, R> responseType(ParameterizedTypeReference<R> responseType) {
            this.responseType = responseType;
            return this;
        }
        Builder<T, R> uri(URI uri) {
            this.uri = uri;
            return this;
        }

        public APIRequest<T, R> build() {
            return new APIRequest<>(this);
        }
    }

}
