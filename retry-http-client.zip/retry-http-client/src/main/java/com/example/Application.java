package com.example;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClient;

import java.util.Map;

import static org.springframework.web.client.RestClient.builder;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	ApplicationRunner applicationRunner(RetryHttpClient httpClient, RestClient restClient) {
		return args -> {
			APIRequest<Void, String> apiRequest = APIRequest.<Void, String>builder()
					.restClient(restClient)
					.baseUrl("http://localhost:8080")
					.responseType(new ParameterizedTypeReference<>() {})
//					.httpMethod(HttpMethod.POST)
//					.fixedDelay(3)
//					.maxRetryCount(3)
//					.httpHeaders(new HttpHeaders())
//					.requestParams(new LinkedMultiValueMap<>())
//					.uriVariables(Map.of())
					.build();

//			String body = httpClient.getResponseEntity(apiRequest).getBody();
			String body = httpClient.getResponse(apiRequest).getBody();
			System.out.println("body = " + body);
		};
	}

}
